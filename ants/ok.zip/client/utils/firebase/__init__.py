""" A custom build of pyrebase and sseclient
for use in the collaboration protocol.
"""
